from __future__ import annotations
from storage.models import IntelligencePacket, ProspectInput
from storage.memory import memory
from ingestion.website import fetch_company_site
from ingestion.company import build_company_context as build_raw_company_context
from ingestion.crm import get_prior_interactions
from intelligence.enrichment import resolve_identity, build_person_context, build_company_context
from intelligence.reasoning import build_opportunity, build_conversation_strategy


async def run_pre_call(prospect: ProspectInput, objective: str, product: str, role_hint: str | None = None) -> IntelligencePacket:
    existing = memory.find_by_identity(prospect.email, prospect.linkedin_url)
    prospect_id = existing.prospect_id if existing else None

    identity = resolve_identity(prospect)

    site_data = await fetch_company_site(prospect.company_url)
    raw_company = build_raw_company_context(prospect.company, site_data)
    company_context = build_company_context(raw_company)

    person_context = build_person_context(prospect, role_hint=role_hint)

    opportunity = build_opportunity(company_context, person_context, product)
    strategy = build_conversation_strategy(opportunity, objective)

    prior = get_prior_interactions(prospect_id) if prospect_id else []

    packet = IntelligencePacket(
        **({"prospect_id": prospect_id} if prospect_id else {}),
        identity=prospect,
        company_context=company_context,
        person_context=person_context,
        signals=company_context.recent_signals,
        opportunity=opportunity,
        conversation_strategy=strategy,
        previous_interactions=prior,
    )
    memory.save_packet(packet)
    return packet
