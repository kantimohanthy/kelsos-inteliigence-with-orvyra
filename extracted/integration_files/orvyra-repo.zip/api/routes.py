from __future__ import annotations
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from storage.models import ProspectInput, IntelligencePacket, PostCallInput, CallAnalysis
from interactions.pre_call import run_pre_call
from interactions.post_call import run_post_call
from api.auth import require_api_key

router = APIRouter(prefix="/v1/intelligence", tags=["intelligence"], dependencies=[Depends(require_api_key)])


class PreCallRequest(BaseModel):
    prospect: ProspectInput
    objective: str
    product: str = "Klesos"
    role_hint: str | None = None


@router.post("/pre-call", response_model=IntelligencePacket)
async def pre_call(req: PreCallRequest) -> IntelligencePacket:
    """Klesos -> Orvyra, before a call. Returns the full IntelligencePacket:
    company/person context, opportunity hypothesis, and conversation strategy."""
    return await run_pre_call(req.prospect, req.objective, req.product, req.role_hint)


@router.post("/post-call", response_model=CallAnalysis)
def post_call(payload: PostCallInput) -> CallAnalysis:
    """Klesos -> Orvyra, after a call. Returns analysis + next best action,
    and updates the prospect's intelligence memory for the next call."""
    return run_post_call(payload)
